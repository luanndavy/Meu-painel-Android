package com.example.painelflutuante;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(16,16,16));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(16,16,16));

        TextView title = new TextView(this);
        title.setText("PAINEL FLUTUANTE");
        title.setTextColor(Color.rgb(57,255,20));
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView info = new TextView(this);
        info.setText("Demonstração segura\n\n1. Autorize a sobreposição.\n2. Inicie o painel.\n3. Arraste a bolinha e toque para abrir.\n\nA depuração Wi-Fi pode ser ativada nas Opções do desenvolvedor, mas não é necessária para a janela flutuante.");
        info.setTextColor(Color.WHITE);
        info.setTextSize(16);
        info.setPadding(0, dp(16), 0, dp(22));
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button permission = button("1 — Autorizar painel flutuante");
        permission.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startPanel();
            }
        });
        root.addView(permission, fullWidth());

        Button start = button("2 — Iniciar painel");
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else {
                startPanel();
            }
        });
        root.addView(start, fullWidth());

        Button wifi = button("Como ativar depuração Wi-Fi");
        wifi.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
                .setTitle("Depuração Wi-Fi")
                .setMessage("Abra Configurações > Sobre o telefone e toque 7 vezes em Número da versão (se necessário). Depois, abra Opções do desenvolvedor > Depuração sem fio e ative. Os nomes podem variar conforme o fabricante.\n\nEste app de demonstração não precisa dessa opção para funcionar.")
                .setPositiveButton("OK", null).show());
        root.addView(wifi, fullWidth());

        setContentView(root);
    }

    private LinearLayout.LayoutParams fullWidth() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, dp(7), 0, dp(7));
        return p;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(57,255,20));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(38,38,38)));
        return b;
    }

    private void startPanel() {
        startService(new Intent(this, FloatingPanelService.class));
        finish();
    }
}
