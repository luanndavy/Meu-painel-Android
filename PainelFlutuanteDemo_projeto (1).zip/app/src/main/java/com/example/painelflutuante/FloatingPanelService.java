package com.example.painelflutuante;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private boolean expanded = false;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        createBubble();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.rgb(57,255,20));
        return d;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.rgb(57,255,20));
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void createBubble() {
        bubble = text("FF", 16, true);
        bubble.setBackground(shape(Color.rgb(20,20,20), 32));
        bubbleParams = new WindowManager.LayoutParams(dp(58), dp(58), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(18); bubbleParams.y = dp(180);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; long downTime;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = bubbleParams.x; startY = bubbleParams.y;
                        downTime = System.currentTimeMillis(); return true;
                    case MotionEvent.ACTION_MOVE:
                        bubbleParams.x = startX + (int)(e.getRawX() - downX);
                        bubbleParams.y = startY + (int)(e.getRawY() - downY);
                        wm.updateViewLayout(bubble, bubbleParams); return true;
                    case MotionEvent.ACTION_UP:
                        if (System.currentTimeMillis() - downTime < 250 &&
                            Math.abs(e.getRawX()-downX) < dp(8) && Math.abs(e.getRawY()-downY) < dp(8)) togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleParams);
    }

    private void togglePanel() {
        if (expanded) {
            if (panel != null) wm.removeView(panel);
            panel = null; expanded = false; return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        box.setBackground(shape(Color.rgb(17,17,17), 16));

        TextView header = text("PAINEL DEMO  ×", 16, true);
        box.addView(header, new LinearLayout.LayoutParams(-1, dp(42)));
        header.setOnClickListener(v -> togglePanel());

        addDemoRow(box, "ESP LINE — demonstração");
        addDemoRow(box, "ESP BOX — demonstração");
        addDemoRow(box, "Mira de treino");
        TextView note = text("Não conectado ao Free Fire", 11, false);
        note.setTextColor(Color.LTGRAY);
        box.addView(note, new LinearLayout.LayoutParams(-1, dp(34)));

        TextView close = text("FECHAR PAINEL", 13, true);
        close.setBackground(shape(Color.rgb(35,35,35), 10));
        box.addView(close, new LinearLayout.LayoutParams(-1, dp(40)));
        close.setOnClickListener(v -> togglePanel());

        panelParams = new WindowManager.LayoutParams(dp(250), -2, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = bubbleParams.x;
        panelParams.y = bubbleParams.y + dp(65);
        panel = box;
        wm.addView(panel, panelParams);
        expanded = true;
    }

    private void addDemoRow(LinearLayout box, String label) {
        TextView row = text("●  " + label, 13, false);
        row.setBackground(shape(Color.rgb(30,30,30), 9));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(42));
        p.setMargins(0, dp(4), 0, dp(4));
        box.addView(row, p);
        row.setOnClickListener(v -> Toast.makeText(this,
                "Demonstração visual: não altera o jogo.", Toast.LENGTH_SHORT).show());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
