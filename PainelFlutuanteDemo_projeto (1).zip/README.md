# Painel Flutuante Demo (Android)

Projeto-fonte Android nativo em Java. Inclui bolha flutuante arrastável e painel demonstrativo preto/verde. ESP LINE/BOX são apenas opções ilustrativas e não leem dados do Free Fire.

## Compilar APK
1. Instale o Android Studio e o Android SDK (API 35).
2. Abra a pasta `PainelFlutuanteDemo` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio mostrará o caminho do APK gerado.

## No celular
- Instale o APK gerado.
- Abra o app e toque em “Autorizar painel flutuante”.
- Conceda “Exibir sobre outros apps”.
- Toque em “Iniciar painel”; a bolinha FF aparecerá e pode ser arrastada.
- Toque na bolinha para abrir/fechar o painel.

## Depuração Wi-Fi
O app explica como habilitar a opção nas configurações, mas a depuração Wi-Fi não é necessária para a sobreposição e não é usada como mecanismo de segurança. Os nomes dos menus variam conforme a versão e fabricante do Android.

Este é um projeto demonstrativo. Não inclui aimbot, leitura de memória, injeção, automação de tiros nem funções que manipulem o Free Fire. Não há promessa de evitar banimentos.
